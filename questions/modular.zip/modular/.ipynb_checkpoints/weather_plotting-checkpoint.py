import click

from myweatherlib.plotting import plot_months
from myweatherlib.preprocessing import load_and_preprocess


@click.command()
@click.option("--month", required=True, type=str, help="Which month to plot in YYYY-MM format")
def main(month):
    """
    Plot temperatures and precipication from a weather CSV
    """
    plot_months(
        weather_data=load_and_preprocess("weather_data.csv"),
        months=[month],
        location_label="Helsinki airport"
    )


if __name__ == "__main__":
    main()