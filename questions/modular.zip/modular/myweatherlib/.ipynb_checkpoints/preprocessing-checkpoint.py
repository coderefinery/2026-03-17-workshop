import pandas as pd


def load_and_preprocess(csv_filename):
    # read data
    data = pd.read_csv(csv_filename)
    
    # combine 'date' and 'time' into a single column 'recorded_at' as type datetime
    data["recorded_at"] = pd.to_datetime(data["date"] + " " + data["time"])
    
    # set 'recorded_at' as index for convenience
    data = data.set_index("recorded_at")

    return data