import matplotlib.pyplot as plt


def plotdata(x, y, y_label, location_label, color, *, show_y_mean=False):
    fig, ax = plt.subplots()
    
    # temperature time series
    ax.plot(
        x,
        y,
        label=y_label,
        color=color,
    )

    if show_y_mean:
        values = y.values
        mean_temp = sum(values) / len(values)
        
        # mean temperature (as horizontal dashed line)
        ax.axhline(
            y=mean_temp,
            label=f"mean {y_label}: {mean_temp:.1f}",
            color=color,
            linestyle="--",
        )
    
    ax.set_title(f"{y_label} at {location_label}")
    ax.set_xlabel("date and time")
    ax.set_ylabel(y_label)
    ax.legend()
    ax.grid(True)
    
    # format x-axis for better date display
    fig.autofmt_xdate()

    return fig


def plot_months(weather_data, months, location_label):
    for month in months:
        # keep only january data using datetime period indexing
        month_data = weather_data.loc[month]
    
        fig = plotdata(
            month_data.index,
            month_data["air_temperature_celsius"],
            y_label="air temperature (C)",
            location_label=location_label,
            color="red",
            show_y_mean=True
        )
        
        fig.savefig(f"{month}-temperature.png")
    
        fig = plotdata(
            month_data.index,
            month_data["precipitation_mm"],
            y_label="precipitation (mm)",
            location_label=location_label,
            color="blue"
        )
            
        fig.savefig(f"{month}-precipitation.png")